export class Constants {
  public readonly API_ENDPOINT: string = 'http://localhost:3000';  
}