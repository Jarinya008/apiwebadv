export class Constants {
  public readonly API_ENDPOINT: string = 'http://localhost:3000';  
  //public readonly API_ENDPOINT: string = 'http://202.28.34.197';
}